
#ifndef GRAPHICS_H
#define GRAPHICS_H
#include <graphics.h>
#endif

#ifndef TIME_H
#define TIME_H
#include <ctime>
#endif

#ifndef STRING_H
#define STRING_H
#include <string>
using namespace std;
#endif
